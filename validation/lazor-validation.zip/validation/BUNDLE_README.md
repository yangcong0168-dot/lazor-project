# Lazor final validation evidence

Extract this archive into the project checkout root. It preserves project-relative
paths under outputs/, tmp/ and scripts/. No production or original evidence file
was changed while packaging. The archive contains the final 5,997-case matrix,
164 frozen fresh-seed inputs, planted witnesses, all formal adaptive JSON/JSONL
records (including both fresh runs), the final unit-test log, JSON profiles, three
frozen Python source trees, and the scripts required by the two oracle audits and
the paired-results summary. Other historical experiments and binary profiles are
deliberately excluded. The separate clean-checkout log is distributed in the Git
repository's validation directory.

## Integrity and path normalization

PACKAGE_MANIFEST.json records each original file SHA-256 and its packaged SHA-256.
SHA256SUMS.txt additionally covers generated metadata. Existing input_sha256,
code_sha256, manifest_sha256, generator_script_sha256 and other historical hashes
in records are unchanged: they identify the ORIGINAL artifact, not an edited copy.
Use original_sha256 in PACKAGE_MANIFEST.json to resolve a historical hash when a
metadata file was normalized. Frozen Python sources and .bff inputs must retain
their exact original bytes; the packager verifies this condition.

Only real machine path prefixes are normalized, recursively including JSON keys.
Paths inside the project become project-relative paths with forward slashes.
External user-profile paths, if any, become external/user-profile/... metadata
placeholders; these external files are not included or required for the recorded
results. Values, cases, timings, counters, seeds and historical hash strings are
not replaced. This is a redistribution copy, not a new benchmark run.

## Reproduce the checks

Use Python 3.12 or a compatible Python 3. Install the project's requirements for
optional SMT features. Search and independent DFS audits use the standard library.
Run from the project checkout root:

```text
python scripts/package_validation.py --verify validation/lazor-validation.zip
python tmp/summarize_adaptive.py
python tmp/adaptive_experiments/audit_opening.py --candidate-root tmp/adaptive_release --oracle-root tmp/optimization_baseline --output outputs/replayed_oracle_default.json
python tmp/adaptive_experiments/audit_opening.py --candidate-root tmp/adaptive_release --oracle-root tmp/optimization_baseline --force-bitboard --restart-after 0 --output outputs/replayed_oracle_forced.json
python tmp/adaptive_experiments/audit_early_guidance.py --candidate-root tmp/adaptive_release --oracle-root tmp/optimization_baseline --output outputs/replayed_oracle_guidance.json
python -m unittest discover -s tests -v
```

The audit_cache.py file is a fixture helper imported by the two audits; its own
historical main program is not part of the final reproduction workflow. Audit
outputs must be new paths. Unit tests and the current benchmark harness are in the
main Git checkout. Frozen fresh inputs are supplied directly, so recreating older
holdout-exclusion corpora is unnecessary; historical exclusion hashes remain in
their manifest for provenance.

To repeat timing, obtain the separate search_tables.sqlite3 Release asset and put
it at data/search_tables.sqlite3. Its expected SHA-256 is recorded in
outputs/adaptive_optimization/release_integrity.json. The 101 MiB database is not
duplicated in this validation ZIP. Set LAZOR_TABLE_DB to its absolute local path;
for example, in PowerShell:

```powershell
$env:LAZOR_TABLE_DB = (Resolve-Path data/search_tables.sqlite3).Path
python -m lazor.full_benchmark --manifest outputs/scaling_full/manifest.json --root tmp/adaptive_baseline --output outputs/replayed_baseline.jsonl --timeout 1
python -m lazor.full_benchmark --manifest outputs/scaling_full/manifest.json --root tmp/adaptive_release --output outputs/replayed_release.jsonl --timeout 1
python -m lazor.full_benchmark --manifest outputs/adaptive_optimization/fresh_holdout/manifest.json --root tmp/adaptive_baseline --output outputs/replayed_fresh_baseline.jsonl --timeout 1
python -m lazor.full_benchmark --manifest outputs/adaptive_optimization/fresh_holdout/manifest.json --root tmp/adaptive_release --output outputs/replayed_fresh_release.jsonl --timeout 1
```

Run timing commands sequentially on an idle machine. Cache warmness, Python and
hardware affect elapsed time; the original recordings are evidence, not universal
performance guarantees. tmp/recheck_adaptive.py and the JSON profile script are
optional diagnostics. SHA validation alone verifies evidence integrity, not the
correctness of the solver; the independent audits and unit tests provide that
separate check.
