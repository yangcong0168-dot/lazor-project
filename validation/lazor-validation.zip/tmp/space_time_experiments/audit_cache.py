"""Compare frozen frontier solvers through cold/warm cross-puzzle sequences.

The 250 inputs are tiny correctness probes, not a performance benchmark. They
vary targets, static cells, exact inventory and lasers at repeated dimensions;
rectangular transposes deliberately share area but not geometry. Every input
also goes through the original preserved complete-layout DFS and simulator.
No planted answer is supplied to either frontier solver.

Example (run only when the shared benchmark CPU is free)::

    python tmp/space_time_experiments/audit_cache.py \
      --baseline-root tmp/space_time_baseline --candidate-root . \
      --output outputs/space_time_optimization/cache_audit.json

Optional --clear-module adapts the public cache hook without requiring it in
the uncached baseline. Without the hook, cold trials use fresh package aliases.
Timeout=0 tests entry interruption; this does not claim to exercise a timeout
inside cache construction, which has separate API-specific unit tests.
"""

import argparse
from collections import Counter
from contextlib import nullcontext
import hashlib
import importlib
import importlib.util
import json
from pathlib import Path
import random
import sys
from time import perf_counter
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
COUNTERS = ("candidates_tested", "states_expanded", "ray_states_processed",
            "branches_pruned", "optimistic_checks", "forced_assignments",
            "restarts", "assignment_writes", "implicit_cell_reads")
MODES = (("default", {}), ("restart_each_node", {"_RESTART_AFTER": 0}),
         ("small_optical_budget", {"_RESTART_RAY_STATES": 2}))


def load_package(alias, root):
    package = Path(root).resolve() / "lazor"
    spec = importlib.util.spec_from_file_location(
        alias, package / "__init__.py", submodule_search_locations=[str(package)])
    module = importlib.util.module_from_spec(spec)
    sys.modules[alias] = module
    spec.loader.exec_module(module)
    return module


def unload_package(alias):
    for name in list(sys.modules):
        if name == alias or name.startswith(alias + "."):
            del sys.modules[name]


def source_hashes(root):
    return {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted((Path(root).resolve() / "lazor").glob("*.py"))}


def bff(rows, inventory, lasers, targets):
    lines = ["GRID START", *(" ".join(row) for row in rows), "GRID STOP"]
    lines += [f"{kind} {inventory.get(kind, 0)}" for kind in "ABC"]
    lines += ["L " + " ".join(map(str, ray)) for ray in lasers]
    lines += [f"P {x} {y}" for x, y in targets]
    return "\n".join(lines) + "\n"


def cases(seed=61115503, count=250):
    """Five related inputs per group; no more than four movable cells."""
    if count <= 0:
        raise ValueError("count must be positive")
    rng = random.Random(seed)
    output = []
    input_hashes = set()
    dimensions = ((2, 2), (2, 3), (3, 2), (1, 4), (4, 1))
    for group in range(count):
        width, height = dimensions[group % len(dimensions)]
        cells = [rng.choice("oooABCx") for _ in range(width * height)]
        # Explicitly keep the oracle small, while retaining fixed blocks.
        available = [i for i, kind in enumerate(cells) if kind == "o"]
        for index in available[4:]:
            cells[index] = rng.choice("ABCx")
        slots = cells.count("o")
        labels = [rng.choice("oABC") for _ in range(slots)]
        inventory = Counter(labels)
        points = [(x, y) for x in range(2 * width + 1)
                  for y in range(2 * height + 1) if (x + y) & 1]
        lasers = [(*rng.choice(points), rng.choice((-1, 1)), rng.choice((-1, 1)))
                  for _ in range(1 + group % 3)]
        if group % 4 == 0:
            lasers.append(lasers[0])
        targets = rng.sample(points, 1 + group % 3)
        for variant in range(5):
            changed_cells = list(cells)
            changed_inventory = inventory
            changed_lasers = lasers
            changed_targets = targets
            label = ("base", "targets", "static_cells", "inventory", "lasers")[variant]
            if variant == 1:
                changed_targets = rng.sample(points, 1 + (group + 1) % 4)
                if group % 9 == 0:
                    changed_targets.append((1, 1))
            elif variant == 2:
                changed_cells = [rng.choice("ABCx") if kind != "o" else kind
                                 for kind in cells]
                if changed_cells == cells and changed_cells:
                    # Keep inventory valid even when the original was all o.
                    changed_inventory = Counter()
                    changed_cells[group % len(cells)] = "ABCx"[group % 4]
            elif variant == 3:
                # Alternate exact-full singleton inventory and an empty slot.
                kind = "oABC"[(group // 2) % 4]
                changed_inventory = Counter([kind] * (slots if group % 2 else max(0, slots - 1)))
            elif variant == 4:
                changed_lasers = [(*rng.choice(points), rng.choice((-1, 1)), rng.choice((-1, 1)))
                                  for _ in range(1 + (group + 1) % 3)]
            rows = [changed_cells[y * width:(y + 1) * width] for y in range(height)]
            text = bff(rows, changed_inventory, changed_lasers, changed_targets)
            digest = hashlib.sha256(text.encode()).hexdigest()
            if digest in input_hashes:
                continue
            input_hashes.add(digest)
            output.append({"case": len(output), "group": group, "variant": label,
                           "width": width, "height": height, "input_bff": text,
                           "input_sha256": digest})
            if len(output) == count:
                return output
    raise AssertionError("Could not construct enough distinct audit inputs")


class SolverPackage:
    def __init__(self, alias, root, clear_module, clear_function):
        self.alias = alias
        load_package(alias, root)
        self.io = importlib.import_module(alias + ".bff")
        self.search = importlib.import_module(alias + ".search")
        try:
            cache_module = importlib.import_module(alias + "." + clear_module)
        except ModuleNotFoundError as error:
            if error.name != alias + "." + clear_module:
                raise
            cache_module = self.search
        self.clear = getattr(cache_module, clear_function, None)
        if self.clear is not None and not callable(self.clear):
            raise TypeError("Cache clear hook must be callable")

    def solve(self, text, limits, timeout=None):
        with patch.multiple(self.search, **limits) if limits else nullcontext():
            return self.search.solve_search(self.io.parse_bff(text), timeout=timeout)


def signature(result):
    placement = None if not result.solved else sorted(
        (x, y, kind) for (x, y), kind in result.solution.layout.placements.items())
    return {"status": result.status, "placement": placement,
            "counters": {name: getattr(result, name) for name in COUNTERS}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-root", type=Path, default=ROOT / "tmp/space_time_baseline")
    parser.add_argument("--candidate-root", type=Path, default=ROOT)
    parser.add_argument("--oracle-root", type=Path, default=ROOT / "tmp/optimization_baseline")
    parser.add_argument("--clear-module", default="search_tables")
    parser.add_argument("--clear-function", default="clear_search_caches")
    parser.add_argument("--require-clear", action="store_true")
    parser.add_argument("--seed", type=int, default=61115503)
    parser.add_argument("--count", type=int, default=250)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("Use a new audit output path")
    if args.count <= 0:
        parser.error("--count must be positive")
    roots = {name: getattr(args, name + "_root") for name in ("baseline", "candidate", "oracle")}
    hashes = {name: source_hashes(root) for name, root in roots.items()}
    load_package("cache_audit_original", args.oracle_root)
    oracle_io = importlib.import_module("cache_audit_original.bff")
    oracle_dfs = importlib.import_module("cache_audit_original.dfs_baseline")
    oracle_sim = importlib.import_module("cache_audit_original.simulation")
    baseline = SolverPackage("cache_audit_baseline", args.baseline_root,
                             args.clear_module, args.clear_function)
    candidate = SolverPackage("cache_audit_candidate", args.candidate_root,
                              args.clear_module, args.clear_function)
    if args.require_clear and candidate.clear is None:
        parser.error("Requested cache clear hook is missing")
    fixtures = cases(args.seed, args.count)
    started = perf_counter()
    rows, expected = [], {}
    report = {"passed": False, "seed": args.seed, "case_count": len(fixtures),
              "unique_input_hashes": len({row["input_sha256"] for row in fixtures}),
              "code_sha256": hashes, "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "cache_clear_hook": args.clear_module + "." + args.clear_function
                                  if candidate.clear else None,
              "cold_strategy": "clear" if candidate.clear else "fresh_package",
              "oracle_scope": "Preserved reconstructed complete-layout DFS and its original simulator",
              "timeout_scope": "Entry timeout=0; mid-build interruption tested separately",
              "fixtures": fixtures, "results": rows}

    def verify(fixture, result, phase):
        key = fixture["case"]
        actual = signature(result)
        independent = True
        if result.solved:
            original = oracle_io.parse_bff(fixture["input_bff"])
            placements = result.solution.layout.placements
            independent = (Counter(placements.values()) == Counter(
                {kind: count for kind, count in original.block_counts.items() if count})
                and oracle_sim.simulate(original, placements).is_solution)
        row = {"case": key, "phase": phase, "mode": MODES[key % 3][0],
               **actual, "independent_verified": independent}
        rows.append(row)
        if not independent or actual != expected[key]:
            raise AssertionError({"failure": row, "expected": expected[key],
                                  "input_bff": fixture["input_bff"]})

    try:
        for fixture in fixtures:
            index, text = fixture["case"], fixture["input_bff"]
            limits = MODES[index % 3][1]
            original = oracle_io.parse_bff(text)
            exhaustive = oracle_dfs.solve_dfs(original, timeout=None)
            result = baseline.solve(text, limits)
            if result.status != exhaustive.status:
                raise AssertionError(("baseline_oracle", index, result.status, exhaustive.status))
            expected[index] = signature(result)
            verify(fixture, result, "baseline")
            if candidate.clear:
                candidate.clear()
                cold = candidate
            else:
                cold = SolverPackage("cache_audit_cold", args.candidate_root,
                                     args.clear_module, args.clear_function)
            verify(fixture, cold.solve(text, limits), "cold")
            if not candidate.clear:
                unload_package("cache_audit_cold")
        if candidate.clear:
            candidate.clear()
        # Adjacent target/grid/domain/laser variants share a cache, then a
        # deterministic shuffle revisits them with different preceding inputs.
        shuffled = list(fixtures)
        random.Random(args.seed ^ 0xCAB1E).shuffle(shuffled)
        for phase, ordered in (("warm_forward", fixtures), ("warm_shuffled", shuffled)):
            for fixture in ordered:
                index, text = fixture["case"], fixture["input_bff"]
                limits = MODES[index % 3][1]
                if index % 17 == 0:
                    interrupted = candidate.solve(text, limits, timeout=0)
                    if interrupted.status != "timeout":
                        raise AssertionError(("entry_timeout", index, interrupted.status))
                verify(fixture, candidate.solve(text, limits), phase)
        if {name: source_hashes(root) for name, root in roots.items()} != hashes:
            raise AssertionError("Source files changed during the audit")
        report["passed"] = True
    except Exception as error:
        report["failure"] = repr(error)
        raise
    finally:
        report["elapsed_seconds"] = perf_counter() - started
        report["trial_count"] = len(rows)
        report["phase_statuses"] = {phase: dict(Counter(row["status"] for row in rows
                                                      if row["phase"] == phase))
                                    for phase in sorted({row["phase"] for row in rows})}
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: report[key] for key in ("passed", "case_count", "trial_count",
                                                  "elapsed_seconds", "phase_statuses")}, indent=2))


if __name__ == "__main__":
    main()
