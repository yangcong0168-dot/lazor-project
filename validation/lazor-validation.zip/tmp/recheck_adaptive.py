"""Alternating cold/warm repetitions of development cases and observed slowdowns.

Diagnostic only: does not select or modify the already frozen candidate.
No fresh-holdout input is used.
"""
import importlib
import importlib.util
import json
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/adaptive_optimization"


def package(name, path):
    spec = importlib.util.spec_from_file_location(name, path / "lazor/__init__.py",
                                                submodule_search_locations=[str(path / "lazor")])
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return importlib.import_module(name + ".search"), importlib.import_module(name + ".bff")


def main():
    modules = {name:package("adaptive_recheck_" + name, ROOT / "tmp" / path)
               for name, path in (("baseline", "adaptive_baseline"), ("release", "adaptive_release"))}
    panel = json.loads((OUT / "training_panel.json").read_text(encoding="utf-8"))["cases"]
    comparison = json.loads((OUT / "comparison.json").read_text(encoding="utf-8"))
    panel_ids = [row["case_id"] for row in panel]
    ids = list(dict.fromkeys(panel_ids + [row["case"] for row in comparison["full"]["regressions"][:12]]))
    expected = {row["case_id"]:row["status"] for row in panel}
    records = []
    for index, case in enumerate(ids):
        for repeat in range(3):
            order = ("baseline", "release") if (index + repeat) % 2 == 0 else ("release", "baseline")
            for name in order:
                solver, parser = modules[name]
                puzzle = parser.load_bff(ROOT / "outputs/scaling_full/boards" / (case + ".bff"))
                solver.configure_search_database(ROOT / "data/search_tables.sqlite3")
                for mode in ("cold", "warm"):
                    result = solver.solve_search(puzzle, timeout=1)
                    assert result.status == expected.get(case, "solved"), (case, name, result.status)
                    if result.solved:
                        assert solver.simulate(puzzle, result.solution.layout.placements).is_solution
                    records.append(dict(case=case, repeat=repeat, variant=name, mode=mode,
                                        seconds=result.elapsed_seconds, status=result.status,
                                        nodes=result.states_expanded, rays=result.ray_states_processed))
        if (index + 1) % 40 == 0:
            print(f"Recheck {index + 1}/{len(ids)}", flush=True)
    medians = {(case, name, mode):statistics.median(row["seconds"] for row in records
                if (row["case"], row["variant"], row["mode"]) == (case, name, mode))
               for case in ids for name in modules for mode in ("cold", "warm")}
    def totals(cases):
        return {mode:{name:sum(medians[case, name, mode] for case in cases) for name in modules}
                for mode in ("cold", "warm")}
    result = dict(scope=__doc__, cases=len(ids), repeats=3, records=records,
                  panel=totals(panel_ids),
                  panel_by_size={f"{low}-{high}":totals([case for case in panel_ids if low <= int(case[1:3]) <= high])
                                 for low, high in ((4, 8), (9, 16), (17, 28), (29, 44))},
                  regressions=[dict(case=case, medians=totals([case])) for case in ids if case not in panel_ids
                               or case in {row["case"] for row in comparison["full"]["regressions"][:12]}])
    (OUT / "recheck.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({key:value for key, value in result.items() if key != "records"}, indent=2))


if __name__ == "__main__":
    main()
