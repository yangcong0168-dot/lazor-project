"""Independent exactness audit for feature-based opening policies.

Prepared before candidate selection. Run only after the benchmark coordinator
releases CPU. Ninety-six boundary fixtures cover both sides of size thresholds,
transposed rectangles, B inventory, fixed blocks, target changes and multiple
sources. Only four cells are movable, so the preserved complete-layout DFS is
an independent exhaustive oracle even on 44x44 boards. A further 250 distinct
small inputs exercise ordinary backtracking. These are correctness development
fixtures, not the separate post-freeze 164-case performance holdout.
"""

import argparse
from collections import Counter
from dataclasses import replace
import hashlib
import importlib
import importlib.util
import json
from pathlib import Path
import sys
from time import perf_counter
from unittest.mock import patch
from contextlib import nullcontext

ROOT = Path(__file__).resolve().parents[2]
DIMENSIONS = ((4, 4), (8, 8), (9, 9), (16, 16), (17, 17), (28, 28), (29, 29), (44, 44),
              (4, 44), (44, 4), (8, 9), (9, 8), (16, 17), (17, 16), (28, 29), (29, 28))


def module_from_file(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def load_package(alias, root):
    package = Path(root).resolve() / "lazor"
    spec = importlib.util.spec_from_file_location(alias, package / "__init__.py",
                                                submodule_search_locations=[str(package)])
    module = importlib.util.module_from_spec(spec)
    sys.modules[alias] = module
    spec.loader.exec_module(module)
    return module


def hashes(root):
    return {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted((Path(root) / "lazor").glob("*.py"))}


def boundary_cases(old_io, old_sim, bff):
    cases = []
    inventories = ({"A": 1, "B": 1, "C": 1}, {"A": 1, "C": 2}, {"B": 2, "C": 2},
                   {"A": 2, "C": 2}, {"B": 4}, {})
    for width, height in DIMENSIONS:
        cx, cy = width // 2, height // 2
        for variant, inventory in enumerate(inventories):
            grid = [["x"] * width for _ in range(height)]
            movable = [(cx - 1, cy - 1), (cx, cy - 1), (cx - 1, cy), (cx, cy)]
            for x, y in movable:
                grid[y][x] = "o"
            if variant % 2:
                for (x, y), kind in zip(((cx - 2, cy - 1), (cx + 1, cy), (cx, cy + 1)), "ACB"):
                    if 0 <= x < width and 0 <= y < height and (x, y) not in movable:
                        grid[y][x] = kind
            lasers = [(2 * cx, 2 * cy - 1, 1, 1)]
            if variant >= 2:
                lasers += [(2 * cx, 2 * cy + 1, -1, -1), lasers[0]]
            preliminary = bff(grid, inventory, lasers, [(lasers[0][0], lasers[0][1])])
            puzzle = old_io.parse_bff(preliminary)
            labels = [kind for kind in "ABC" for _ in range(inventory.get(kind, 0))]
            placement = {position: kind for position, kind in zip(movable, labels)}
            trace = old_sim.simulate(puzzle, placement)
            sources = {(x, y) for x, y, _, _ in lasers}
            onward = sorted(trace.visited_points - sources,
                            key=lambda p: (-abs(p[0] - 2 * cx) - abs(p[1] - 2 * cy), p))
            targets = onward[:1 + variant % 3] or [min(sources)]
            if variant >= 3:
                # An odd-parity target avoids relying solely on the trivial
                # parity early exit; the independent DFS decides feasibility.
                targets = list(dict.fromkeys(targets + [(2 * width, 1)]))
            text = bff(grid, inventory, lasers, targets)
            cases.append({"id": f"boundary_{width}x{height}_{variant}", "input_bff": text,
                          "width": width, "height": height, "variant": variant,
                          "source_count": len(lasers), "target_count": len(targets)})
    return cases


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-root", type=Path, default=ROOT)
    parser.add_argument("--oracle-root", type=Path, default=ROOT / "tmp/optimization_baseline")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--force-bitboard", action="store_true",
                        help="Force batch propagation and a check every node, including tiny boards.")
    parser.add_argument("--restart-after", type=int,
                        help="Override the bounded-stage decision budget for restoration tests.")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("Use a new output path")
    before = {"candidate": hashes(args.candidate_root), "oracle": hashes(args.oracle_root)}
    load_package("opening_old_oracle", args.oracle_root)
    load_package("opening_candidate", args.candidate_root)
    old_io = importlib.import_module("opening_old_oracle.bff")
    old_sim = importlib.import_module("opening_old_oracle.simulation")
    old_dfs = importlib.import_module("opening_old_oracle.dfs_baseline")
    new_io = importlib.import_module("opening_candidate.bff")
    new_search = importlib.import_module("opening_candidate.search")
    original_choose = new_search.choose_opening
    def force_batch(*arguments, **kwargs):
        return replace(original_choose(*arguments, **kwargs), use_bitboard=True,
                       optimistic_period=1, geometry_database=False, predecessor_database=False)
    old_cache_audit = module_from_file("opening_audit_fixtures", ROOT / "tmp/space_time_experiments/audit_cache.py")
    fixtures = boundary_cases(old_io, old_sim, old_cache_audit.bff)
    fixtures += [{"id": "small_" + str(row["case"]), **row}
                 for row in old_cache_audit.cases(seed=61115503, count=250)]
    results = []
    started = perf_counter()
    report = {"passed": False, "candidate_code_sha256": before["candidate"],
              "oracle_code_sha256": before["oracle"], "boundary_cases": 96, "small_cases": 250,
              "scope": "Independent complete-layout DFS correctness, not a performance or held-out claim.",
              "forced_bitboard": args.force_bitboard, "restart_after": args.restart_after,
              "audit_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "fixture_helper_sha256": hashlib.sha256(Path(old_cache_audit.__file__).read_bytes()).hexdigest(),
              "results": results}
    try:
        for fixture in fixtures:
            text = fixture["input_bff"]
            original = old_io.parse_bff(text)
            expected = old_dfs.solve_dfs(original, timeout=None)
            with patch.object(new_search, "choose_opening", side_effect=force_batch) if args.force_bitboard else nullcontext():
                with patch.object(new_search, "_RESTART_AFTER", args.restart_after) if args.restart_after is not None else nullcontext():
                    actual = new_search.solve_search(new_io.parse_bff(text), timeout=None)
            valid = not actual.solved or (
                Counter(actual.solution.layout.placements.values()) == Counter(
                    {kind: count for kind, count in original.block_counts.items() if count})
                and old_sim.simulate(original, actual.solution.layout.placements).is_solution)
            row = {**fixture, "input_sha256": hashlib.sha256(text.encode()).hexdigest(),
                   "expected_status": expected.status, "actual_status": actual.status,
                   "independent_verified": valid, "nodes": actual.states_expanded,
                   "rays": actual.ray_states_processed, "restarts": actual.restarts}
            results.append(row)
            if expected.status != actual.status or not valid:
                raise AssertionError(row)
        if before != {"candidate": hashes(args.candidate_root), "oracle": hashes(args.oracle_root)}:
            raise AssertionError("Source changed during audit")
        report["passed"] = True
    except Exception as error:
        report["failure"] = repr(error)
        raise
    finally:
        report["elapsed_seconds"] = perf_counter() - started
        report["candidate_trials"] = len(results)
        report["status_counts"] = dict(Counter(row["actual_status"] for row in results))
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: report[key] for key in ("passed", "candidate_trials", "elapsed_seconds", "status_counts")}, indent=2))


if __name__ == "__main__":
    main()
