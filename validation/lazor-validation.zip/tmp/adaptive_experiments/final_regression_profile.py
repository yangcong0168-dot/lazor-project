"""Read-only warm cProfile diagnostics for frozen releases, not benchmark timings."""
import cProfile
import importlib
import importlib.util
import json
from pathlib import Path
import pstats
import sys

ROOT = Path(__file__).resolve().parents[2]


def load_package(alias, path):
    directory = path / "lazor"
    spec = importlib.util.spec_from_file_location(alias, directory / "__init__.py",
        submodule_search_locations=[str(directory)])
    module = importlib.util.module_from_spec(spec)
    sys.modules[alias] = module
    spec.loader.exec_module(module)


def main():
    destination = ROOT / "outputs/adaptive_optimization/profiles"
    destination.mkdir(parents=True, exist_ok=True)
    results = []
    cases = ("n24_a06_c06_obstacles", "n27_a09_c08_open", "n13_a07_c05_obstacles")
    names = ("solve_search", "optimistic", "assign", "undo", "reverse_distances",
             "preferred_order", "choose_goal", "simulate", "frontier_priority", "checkpoint")
    for version in ("baseline", "release"):
        package = "final_profile_" + version
        load_package(package, ROOT / "tmp" / ("adaptive_" + version))
        search = importlib.import_module(package + ".search")
        io = importlib.import_module(package + ".bff")
        tables = importlib.import_module(package + ".search_tables")
        for case in cases:
            tables.configure_search_database(ROOT / "data/search_tables.sqlite3")
            puzzle = io.load_bff(ROOT / "outputs/scaling_full/boards" / (case + ".bff"))
            warmup = search.solve_search(puzzle, timeout=None)
            assert warmup.solved
            profile = cProfile.Profile()
            result = profile.runcall(search.solve_search, puzzle, timeout=None)
            assert result.solved and result.solution.layout.placements == warmup.solution.layout.placements
            profile.dump_stats(destination / f"{version}_{case}.pstats")
            stats = pstats.Stats(profile)
            functions = [dict(file=file, line=line, function=function, calls=calls,
                              self_seconds=own, cumulative_seconds=cumulative)
                         for (file,line,function), (_,calls,own,cumulative,_) in stats.stats.items()]
            selected = [row for row in functions if row["function"] in names]
            selected.sort(key=lambda row:-row["cumulative_seconds"])
            record = dict(version=version, case=case, profiled_seconds=result.elapsed_seconds,
                          nodes=result.states_expanded, rays=result.ray_states_processed,
                          checks=result.optimistic_checks, batches=getattr(result,"optimistic_batches",0),
                          setup_seconds=getattr(result,"bitboard_setup_seconds",0),
                          selected_functions=selected,
                          largest_self_functions=sorted(functions,key=lambda row:-row["self_seconds"])[:12])
            results.append(record)
            print(version,case,round(result.elapsed_seconds,4),
                  [(row['function'],round(row['self_seconds'],4),round(row['cumulative_seconds'],4)) for row in selected[:6]],flush=True)
    (destination / "regression_profile.json").write_text(json.dumps(dict(
        note="Each package is frozen; warmup precedes cProfile. Profiled times include instrumentation and must not replace formal full-suite timings.",
        results=results),indent=2),encoding="utf-8")


if __name__ == "__main__":
    main()
