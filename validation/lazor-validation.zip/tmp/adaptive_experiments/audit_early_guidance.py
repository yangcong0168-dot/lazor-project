"""Exercise real sparse guided openings against the original exhaustive DFS.

Each board has 16 placeable cells and exactly one movable A, B or C. There
are only 16 complete layouts, including for long rectangles and 44x44 boards.
SAT targets come from an independently simulated complete layout. The UNSAT
control adds an odd-parity point outside the union of all 16 exact traces,
so infeasibility does not rely on the cheap parity shortcut.
"""

import argparse
from collections import Counter
import hashlib
import importlib
import json
from pathlib import Path
from time import perf_counter

from audit_opening import ROOT, hashes, load_package, module_from_file

DIMENSIONS = ((29, 31), (31, 29), (30, 30), (25, 36), (36, 25),
              (44, 44), (4, 225), (225, 4))


def fixtures(old_io, old_sim, bff):
    result = []
    for shape_index, (width, height) in enumerate(DIMENSIONS):
        cx, cy = width // 2, height // 2
        positions = [(x, y) for y in range(cy - 2, cy + 2)
                     for x in range(cx - 2, cx + 2)]
        grid = [["x"] * width for _ in range(height)]
        for x, y in positions:
            grid[y][x] = "o"
        for (x, y), kind in (((width - 1, 0), "A"), ((0, height - 1), "C")):
            if (x, y) not in positions:
                grid[y][x] = kind
        for kind_index, kind in enumerate("ABC"):
            counts = {kind: 1}
            lasers = [(2 * cx, 2 * cy - 1, 1, 1)]
            if (shape_index + kind_index) % 2:
                lasers += [(2 * cx, 2 * cy + 1, -1, -1), lasers[0]]
            sources = {(x, y) for x, y, _, _ in lasers}
            provisional = old_io.parse_bff(bff(grid, counts, lasers, [min(sources)]))
            traces = [old_sim.simulate(provisional, {position: kind}) for position in positions]
            bare_points = old_sim.simulate(provisional, {}).visited_points
            witness = max(traces, key=lambda trace: (len(trace.visited_points - bare_points),
                                                    len(trace.visited_points)))
            onward = sorted(witness.visited_points - sources,
                            key=lambda point: (-abs(point[0] - 2 * cx) - abs(point[1] - 2 * cy), point))
            if not onward:
                raise AssertionError("Expected non-source SAT targets")
            targets = onward[:2]
            reachable_union = set().union(*(trace.visited_points for trace in traces))
            unreachable = next((x, y) for y in range(2 * height + 1) for x in range(2 * width + 1)
                               if (x + y) & 1 and (x, y) not in reachable_union)
            for label, points in (("sat", targets), ("unsat_odd_union", targets + [unreachable])):
                result.append({"id": f"early_{width}x{height}_{kind}_{label}",
                               "width": width, "height": height, "movable_kind": kind,
                               "placeable": 16, "movable": 1, "lasers": len(lasers),
                               "expected": "solved" if label == "sat" else "no_solution",
                               "expected_early": width * height >= 900,
                               "proof": "verified complete-layout witness" if label == "sat"
                                        else "odd target absent from union of all 16 exact traces",
                               "input_bff": bff(grid, counts, lasers, points)})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-root", type=Path, default=ROOT)
    parser.add_argument("--oracle-root", type=Path, default=ROOT / "tmp/optimization_baseline")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("Use a new output path")
    before = {"candidate": hashes(args.candidate_root), "oracle": hashes(args.oracle_root)}
    load_package("early_original", args.oracle_root)
    load_package("early_candidate", args.candidate_root)
    old_io = importlib.import_module("early_original.bff")
    old_sim = importlib.import_module("early_original.simulation")
    old_dfs = importlib.import_module("early_original.dfs_baseline")
    new_io = importlib.import_module("early_candidate.bff")
    new_search = importlib.import_module("early_candidate.search")
    new_policy = importlib.import_module("early_candidate.search_policy")
    common = module_from_file("early_bff_helper", ROOT / "tmp/space_time_experiments/audit_cache.py")
    cases = fixtures(old_io, old_sim, common.bff)
    results = []
    started = perf_counter()
    report = {"passed": False, "case_count": len(cases), "candidate_code_sha256": before["candidate"],
              "oracle_code_sha256": before["oracle"], "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "scope": "Correctness development fixtures; not unseen performance evaluation.", "results": results}
    try:
        for case in cases:
            original = old_io.parse_bff(case["input_bff"])
            expected = old_dfs.solve_dfs(original, timeout=None)
            puzzle = new_io.parse_bff(case["input_bff"])
            policy = new_policy.analyze_opening(puzzle)
            actual = new_search.solve_search(puzzle, timeout=None)
            verified = not actual.solved or (
                Counter(actual.solution.layout.placements.values()) == Counter(
                    {kind: count for kind, count in original.block_counts.items() if count})
                and old_sim.simulate(original, actual.solution.layout.placements).is_solution)
            row = {**case, "input_sha256": hashlib.sha256(case["input_bff"].encode()).hexdigest(),
                   "oracle_status": expected.status, "actual_status": actual.status,
                   "independent_verified": verified, "early_guidance": policy.early_guidance,
                   "opening_strategy": actual.opening_strategy, "bitboard_enabled": actual.bitboard_enabled,
                   "restarts": actual.restarts, "nodes": actual.states_expanded,
                   "rays": actual.ray_states_processed}
            results.append(row)
            if (expected.status != case["expected"] or actual.status != expected.status or not verified
                    or policy.early_guidance != case["expected_early"] or not actual.bitboard_enabled
                    or (case["expected_early"] and actual.solved and actual.restarts < 1)):
                raise AssertionError(row)
        if before != {"candidate": hashes(args.candidate_root), "oracle": hashes(args.oracle_root)}:
            raise AssertionError("Source changed during audit")
        report["passed"] = True
    except Exception as error:
        report["failure"] = repr(error)
        raise
    finally:
        report["elapsed_seconds"] = perf_counter() - started
        report["candidate_trials"] = len(results)
        report["status_counts"] = dict(Counter(row["actual_status"] for row in results))
        report["early_guidance_cases"] = sum(row["early_guidance"] for row in results)
        report["early_guidance_solved_cases"] = sum(row["early_guidance"] and row["actual_status"] == "solved" for row in results)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: report[key] for key in ("passed", "candidate_trials", "status_counts",
                                                  "early_guidance_cases", "early_guidance_solved_cases",
                                                  "elapsed_seconds")}, indent=2))


if __name__ == "__main__":
    main()
