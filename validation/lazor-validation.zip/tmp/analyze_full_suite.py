"""Retain censored runs and pair all full-matrix results, never only wins."""
import argparse
from collections import Counter
import json
from pathlib import Path
import statistics


def load(path):
    entries = [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines()]
    return entries[0], [r for r in entries if r.get("type") == "result"]


def percentile(values, p):
    if not values:
        return None
    ordered = sorted(values)
    index = (len(ordered) - 1) * p
    low = int(index)
    high = min(low + 1, len(ordered) - 1)
    return ordered[low] + (ordered[high] - ordered[low]) * (index - low)


def group(rows, cutoff):
    times = [r["elapsed_seconds"] for r in rows if r.get("timely_correct")]
    return {
        "attempted": len(rows), "status_counts": dict(Counter(r["status"] for r in rows)),
        "correct": sum(bool(r.get("correct_decision")) for r in rows),
        "timely_correct": len(times), "wrong": sum(bool(r.get("wrong_decision")) for r in rows),
        "hard_timeouts": sum(bool(r.get("hard_timeout")) for r in rows),
        "algorithm_seconds_observed": sum(r.get("elapsed_seconds") or 0 for r in rows),
        "par2_seconds": statistics.mean(r["elapsed_seconds"] if r.get("timely_correct") else 2*cutoff for r in rows) if rows else None,
        "completed_p50": percentile(times, .5), "completed_p90": percentile(times, .9),
        "completed_p95": percentile(times, .95), "completed_p99": percentile(times, .99),
        "completed_max": max(times, default=None),
        "decisions": sum(r.get("states_expanded", 0) for r in rows),
        "ray_states": sum(r.get("ray_states_processed", 0) for r in rows),
        "restarts": dict(Counter(r.get("restarts", 0) for r in rows)),
    }


def compact(row):
    return {k: row.get(k) for k in ("case_id", "status", "elapsed_seconds", "size", "A", "C", "family", "states_expanded", "ray_states_processed", "optimistic_checks", "branches_pruned", "forced_assignments", "restarts")}


def describe(path):
    header, rows = load(path)
    cutoff = header["configuration"]["timeout_seconds"]
    return rows, {
        "report": str(Path(path).resolve()), "configuration": header["configuration"],
        "overall": group(rows, cutoff),
        "satisfiable": group([r for r in rows if r["expected_status"] == "solved"], cutoff),
        "by_family": {k: group([r for r in rows if r["family"] == k], cutoff) for k in sorted({r["family"] for r in rows})},
        "by_size": {str(k): group([r for r in rows if r["size"] == k], cutoff) for k in sorted({r["size"] for r in rows})},
        "timeouts": [compact(r) for r in rows if r["status"] == "timeout"],
        "slowest_completed": [compact(r) for r in sorted((r for r in rows if r.get("timely_correct")), key=lambda r: r["elapsed_seconds"], reverse=True)[:60]],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("baseline")
    parser.add_argument("--current")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    before, baseline = describe(args.baseline)
    result = {"baseline": baseline, "quantile_note": "Percentiles only among timely correct completions. Timeouts remain visible in counts, PAR-2 and paired transitions."}
    if args.current:
        after, current = describe(args.current)
        result["current"] = current
        index = {(r["case_id"], r["trial"]): r for r in before}
        pairs = [(index[(r["case_id"], r["trial"])], r) for r in after]
        if len(index) != len(after) or {r["case_id"] for r in before} != {r["case_id"] for r in after}:
            raise ValueError("Mismatched paired cases")
        for a, b in pairs:
            assert a["input_sha256"] == b["input_sha256"]
        ratios = [a["elapsed_seconds"] / b["elapsed_seconds"] for a,b in pairs if a.get("timely_correct") and b.get("timely_correct") and b["elapsed_seconds"] > 0]
        result["paired"] = {
            "status_transitions": dict(Counter(a["status"] + " -> " + b["status"] for a,b in pairs)),
            "matched_completed": len(ratios),
            "speedup_median": statistics.median(ratios), "speedup_geomean": statistics.geometric_mean(ratios),
            "resolved_timeouts": [{"before": compact(a), "after": compact(b)} for a,b in pairs if a["status"]=="timeout" and b.get("timely_correct")],
            "new_timeouts": [{"before": compact(a), "after": compact(b)} for a,b in pairs if a.get("timely_correct") and b["status"]=="timeout"],
            "largest_completed_regressions": [{"before": compact(a), "after": compact(b), "extra_seconds": b["elapsed_seconds"]-a["elapsed_seconds"]} for a,b in sorted(((a,b) for a,b in pairs if a.get("timely_correct") and b.get("timely_correct")), key=lambda p:p[1]["elapsed_seconds"]-p[0]["elapsed_seconds"], reverse=True)[:30]],
        }
    Path(args.output).write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({k: result[k]["overall"] for k in ("baseline", "current") if k in result}, indent=2))


if __name__ == "__main__":
    main()
