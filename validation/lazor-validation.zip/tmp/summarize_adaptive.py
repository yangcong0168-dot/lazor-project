"""Pair frozen journals and expose size-dependent wins and regressions."""
import json
from collections import Counter
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).parent))
from analyze_full_suite import load, group

OUT = ROOT / "outputs/adaptive_optimization"


def paired(basename, aftername, expected):
    ah, before = load(OUT / basename)
    bh, after = load(OUT / aftername)
    assert len(before) == len(after) == expected
    cutoff = ah["configuration"]["timeout_seconds"]
    assert cutoff == bh["configuration"]["timeout_seconds"] == 1
    assert ah["configuration"]["verifier_sha256"] == bh["configuration"]["verifier_sha256"]
    index = {row["case_id"]: row for row in before}
    assert len(index) == expected
    pairs = [(index[b["case_id"]], b) for b in after]
    assert all(a["input_sha256"] == b["input_sha256"] for a, b in pairs)

    def compare(items):
        a, b = [x[0] for x in items], [x[1] for x in items]
        first, second = group(a, cutoff), group(b, cutoff)
        return dict(before=first, after=second,
                    reduction_percent=100 * (1 - second["algorithm_seconds_observed"] /
                                               first["algorithm_seconds_observed"]))

    regressions = sorted(pairs, key=lambda p: p[1]["elapsed_seconds"] - p[0]["elapsed_seconds"], reverse=True)
    result = dict(overall=compare(pairs),
                  satisfiable=compare([p for p in pairs if p[0]["expected_status"] == "solved"]),
                  by_size_group={f"{low}-{high}": compare([p for p in pairs if low <= p[0]["size"] <= high])
                                 for low, high in ((4, 8), (9, 16), (17, 28), (29, 44))},
                  by_family={family: compare([p for p in pairs if p[0]["family"] == family])
                             for family in sorted({p[0]["family"] for p in pairs})},
                  transitions=dict(Counter(a["status"] + " -> " + b["status"] for a, b in pairs)),
                  new_timeouts=[b["case_id"] for a, b in pairs if a["status"] != "timeout" and b["status"] == "timeout"],
                  errors=[b["case_id"] for _, b in pairs if b["status"] == "error" or b.get("wrong_decision")],
                  strategies=dict(Counter(b.get("opening_strategy") for _, b in pairs)),
                  bitboard_cases=sum(bool(b.get("bitboard_enabled")) for _, b in pairs),
                  bitboard_cache_hits=sum(bool(b.get("bitboard_cache_hit")) for _, b in pairs),
                  batch_iterations=sum(b.get("optimistic_batches", 0) for _, b in pairs),
                  batch_setup_seconds=sum(b.get("bitboard_setup_seconds", 0) for _, b in pairs),
                  slower_count=sum(b["elapsed_seconds"] > a["elapsed_seconds"] for a, b in pairs),
                  slower_over_5ms=sum(b["elapsed_seconds"] - a["elapsed_seconds"] > .005 for a, b in pairs),
                  regressions=[dict(case=b["case_id"], before=a["elapsed_seconds"], after=b["elapsed_seconds"],
                                    before_nodes=a.get("states_expanded"), after_nodes=b.get("states_expanded"),
                                    before_rays=a.get("ray_states_processed"), after_rays=b.get("ray_states_processed"),
                                    strategy=b.get("opening_strategy")) for a, b in regressions[:20]])
    return result


if __name__ == "__main__":
    result = dict(full=paired("baseline_search_1s.jsonl", "release_search_1s.jsonl", 5997),
                  fresh=paired("fresh_baseline_search_1s.jsonl", "fresh_release_search_1s.jsonl", 164))
    (OUT / "comparison.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({key: {field: value[field] for field in ("overall", "by_size_group", "new_timeouts", "errors", "strategies")}
                      for key, value in result.items()}, indent=2))
