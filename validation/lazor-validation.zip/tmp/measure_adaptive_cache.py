"""Measure retained bitboard objects and first/repeated compilation overhead."""
import hashlib
import json
from pathlib import Path
import statistics
import sys
from time import perf_counter

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from lazor.search_tables import SearchTables


def retained_bytes(tables):
    seen = set()
    def visit(obj):
        if id(obj) in seen:
            return 0
        seen.add(id(obj))
        size = sys.getsizeof(obj)
        if isinstance(obj, (tuple, list)):
            size += sum(visit(item) for item in obj)
        elif isinstance(obj, dict):
            size += sum(visit(key) + visit(value) for key, value in obj.items())
        return size
    return visit(tables._bitboards._entries)


def main():
    rows = []
    for size in (16, 24, 32, 44):
        cold, warm = [], []
        for _ in range(7):
            # Release the prior iteration before either clock starts. An old
            # `again` reference otherwise makes its deallocation look like
            # the cost of this iteration's cache lookup.
            compiled = again = None
            tables = SearchTables()
            begin = perf_counter()
            compiled, hit = tables.bitboards(size, size, checkpoint=lambda: None)
            cold.append(perf_counter() - begin)
            assert not hit
            begin = perf_counter()
            again, hit = tables.bitboards(size, size, checkpoint=lambda: None)
            warm.append(perf_counter() - begin)
            assert hit and again is compiled
        rows.append(dict(size=size, compile_median_seconds=statistics.median(cold),
                         cache_hit_median_seconds=statistics.median(warm),
                         retained_bytes=retained_bytes(tables), cold_samples=cold, warm_samples=warm))
    tables = SearchTables()
    sequence = []
    for size in range(16, 45):
        tables.bitboards(size, size, checkpoint=lambda: None)
        sequence.append(dict(size=size, retained_bytes=retained_bytes(tables),
                             stats=tables.info()["bitboards"]))
    result = dict(scope="sys.getsizeof of the retained bitboard LRU with shared identities counted once; not process RSS or an active-search memory limit.",
                  initialization="Lazy per dimension; no startup import or rebuild of the existing SQLite database.",
                  code_sha256={name:hashlib.sha256((ROOT / "lazor" / name).read_bytes()).hexdigest()
                               for name in ("bitboard.py", "search_tables.py", "search_policy.py")},
                  sizes=rows, sequence=sequence,
                  peak_retained_bytes=max(row["retained_bytes"] for row in sequence),
                  retained_end_dimensions=list(tables._bitboards._entries))
    output = ROOT / "outputs/adaptive_optimization/cache_memory.json"
    output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({"sizes":rows, "peak_retained_bytes":result["peak_retained_bytes"],
                      "retained_end_dimensions":result["retained_end_dimensions"]}, indent=2))


if __name__ == "__main__":
    main()
